#include "gfx/legato/generated/le_gen_init.h"

static int32_t currentScreen;
static int32_t changingToScreen;

void legato_initializeScreenState(void)
{
    leSetStringTable(&stringTable);

    initializeStrings();

    screenInit_calib();
    screenInit_gbw();
    screenInit_manual();
    screenInit_stats();

    currentScreen = -1;
    changingToScreen = -1;

    legato_showScreen(screenID_gbw);
}

uint32_t legato_getCurrentScreen(void)
{
    return currentScreen;
}

static void legato_hideCurrentScreen(void)
{
    switch(currentScreen)
    {
        case screenID_calib:
        {
            screenHide_calib();
            currentScreen = 0;
            break;
        }
        case screenID_gbw:
        {
            screenHide_gbw();
            currentScreen = 0;
            break;
        }
        case screenID_manual:
        {
            screenHide_manual();
            currentScreen = 0;
            break;
        }
        case screenID_stats:
        {
            screenHide_stats();
            currentScreen = 0;
            break;
        }
    }
}

void legato_showScreen(uint32_t id)
{
    if(changingToScreen >= 0)
        return;

    changingToScreen = id;
}

void legato_updateScreenState(void)
{
    if(changingToScreen >= 0)
    {
        legato_hideCurrentScreen();

        switch(changingToScreen)
        {
            case screenID_calib:
            {
                screenShow_calib();
                break;
            }
            case screenID_gbw:
            {
                screenShow_gbw();
                break;
            }
            case screenID_manual:
            {
                screenShow_manual();
                break;
            }
            case screenID_stats:
            {
                screenShow_stats();
                break;
            }
        }

        currentScreen = changingToScreen;
        changingToScreen = -1;
    }

    switch(currentScreen)
    {
        case screenID_calib:
        {
            screenUpdate_calib();
            break;
        }
        case screenID_gbw:
        {
            screenUpdate_gbw();
            break;
        }
        case screenID_manual:
        {
            screenUpdate_manual();
            break;
        }
        case screenID_stats:
        {
            screenUpdate_stats();
            break;
        }
    }
}

leBool legato_isChangingScreens(void)
{
    return changingToScreen != -1;
}

