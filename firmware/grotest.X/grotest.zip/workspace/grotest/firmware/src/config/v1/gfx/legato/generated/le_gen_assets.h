/*******************************************************************************
 Module for Microchip Legato Graphics Library

  Company:
    Microchip Technology Inc.

  File Name:
    le_gen_assets.h

  Summary:
    Header file containing a list of asset specifications for use with the
    Legato Graphics Stack.


  Description:
    Header file containing a list of asset specifications for use with the
    Legato Graphics Stack.

*******************************************************************************/


// DOM-IGNORE-BEGIN
/*******************************************************************************
* Copyright (C)  Microchip Technology Inc. and its subsidiaries.
*
* Subject to your compliance with these terms, you may use Microchip software
* and any derivatives exclusively with Microchip products. It is your
* responsibility to comply with third party license terms applicable to your
* use of third party software (including open source software) that may
* accompany Microchip software.
*
* THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
* EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
* WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
* PARTICULAR PURPOSE.
*
* IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
* INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
* WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
* BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
* FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
* ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
* THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
*******************************************************************************/

// DOM-IGNORE-END

#ifndef LE_GEN_ASSETS_H
#define LE_GEN_ASSETS_H

// DOM-IGNORE-BEGIN
#ifdef __cplusplus  // Provide C++ Compatibility
extern "C" {
#endif
// DOM-IGNORE-END

#include "gfx/legato/legato.h"

extern const lePalette leGlobalPalette;

/*****************************************************************************
 * Legato Graphics Image Assets
 *****************************************************************************/
/*********************************
 * Legato Image Asset
 * Name:   sum
 * Size:   12x18 pixels
 * Type:   RGB Data
 * Format: RGB_565
 ***********************************/
extern leImage sum;

/*********************************
 * Legato Image Asset
 * Name:   calib_double_active
 * Size:   41x26 pixels
 * Type:   RGB Data
 * Format: RGB_565
 ***********************************/
extern leImage calib_double_active;

/*********************************
 * Legato Image Asset
 * Name:   calib_double_inactive
 * Size:   41x26 pixels
 * Type:   RGB Data
 * Format: RGB_565
 ***********************************/
extern leImage calib_double_inactive;

/*********************************
 * Legato Image Asset
 * Name:   calib_weight_active
 * Size:   27x24 pixels
 * Type:   RGB Data
 * Format: RGB_565
 ***********************************/
extern leImage calib_weight_active;

/*********************************
 * Legato Image Asset
 * Name:   calib_weight_inactive
 * Size:   27x24 pixels
 * Type:   RGB Data
 * Format: RGB_565
 ***********************************/
extern leImage calib_weight_inactive;

/*********************************
 * Legato Image Asset
 * Name:   calib_unit_g
 * Size:   10x17 pixels
 * Type:   RGB Data
 * Format: RGB_565
 ***********************************/
extern leImage calib_unit_g;

/*********************************
 * Legato Image Asset
 * Name:   calib_start
 * Size:   51x17 pixels
 * Type:   RGB Data
 * Format: RGB_565
 ***********************************/
extern leImage calib_start;

/*********************************
 * Legato Image Asset
 * Name:   Symbol_Seite_Cal
 * Size:   36x8 pixels
 * Type:   RGB Data
 * Format: RGB_565
 ***********************************/
extern leImage Symbol_Seite_Cal;

/*********************************
 * Legato Image Asset
 * Name:   Symbol_Stop
 * Size:   46x22 pixels
 * Type:   RGB Data
 * Format: RGB_565
 ***********************************/
extern leImage Symbol_Stop;

/*********************************
 * Legato Image Asset
 * Name:   Symbol_Start
 * Size:   52x17 pixels
 * Type:   RGB Data
 * Format: RGB_565
 ***********************************/
extern leImage Symbol_Start;

/*********************************
 * Legato Image Asset
 * Name:   Symbol_Seite_Manual
 * Size:   36x8 pixels
 * Type:   RGB Data
 * Format: RGB_565
 ***********************************/
extern leImage Symbol_Seite_Manual;

/*********************************
 * Legato Image Asset
 * Name:   Symbol_Seite_Statistik
 * Size:   36x8 pixels
 * Type:   RGB Data
 * Format: RGB_565
 ***********************************/
extern leImage Symbol_Seite_Statistik;

/*********************************
 * Legato Image Asset
 * Name:   Symbol_Manual
 * Size:   21x26 pixels
 * Type:   RGB Data
 * Format: RGB_565
 ***********************************/
extern leImage Symbol_Manual;

/*********************************
 * Legato Image Asset
 * Name:   Symbol_Sekunde
 * Size:   11x15 pixels
 * Type:   RGB Data
 * Format: RGB_565
 ***********************************/
extern leImage Symbol_Sekunde;

/*********************************
 * Legato Image Asset
 * Name:   Symbol_Gramm_ws
 * Size:   11x20 pixels
 * Type:   RGB Data
 * Format: RGB_565
 ***********************************/
extern leImage Symbol_Gramm_ws;

/*********************************
 * Legato Image Asset
 * Name:   Symbol_Statistik_Double
 * Size:   41x25 pixels
 * Type:   RGB Data
 * Format: RGB_565
 ***********************************/
extern leImage Symbol_Statistik_Double;

/*********************************
 * Legato Image Asset
 * Name:   Symbol_Statistik_Manual
 * Size:   13x15 pixels
 * Type:   RGB Data
 * Format: RGB_565
 ***********************************/
extern leImage Symbol_Statistik_Manual;

/*********************************
 * Legato Image Asset
 * Name:   Symbol_Statistik_Single
 * Size:   25x25 pixels
 * Type:   RGB Data
 * Format: RGB_565
 ***********************************/
extern leImage Symbol_Statistik_Single;

/*********************************
 * Legato Image Asset
 * Name:   Symbol_Double
 * Size:   68x42 pixels
 * Type:   RGB Data
 * Format: RGB_565
 ***********************************/
extern leImage Symbol_Double;

/*********************************
 * Legato Image Asset
 * Name:   Symbol_Single
 * Size:   42x42 pixels
 * Type:   RGB Data
 * Format: RGB_565
 ***********************************/
extern leImage Symbol_Single;

/*********************************
 * Legato Image Asset
 * Name:   Symbol_Err
 * Size:   74x31 pixels
 * Type:   RGB Data
 * Format: RGB_565
 ***********************************/
extern leImage Symbol_Err;

/*********************************
 * Legato Image Asset
 * Name:   Symbol_Cal_Gewicht
 * Size:   90x25 pixels
 * Type:   RGB Data
 * Format: RGB_565
 ***********************************/
extern leImage Symbol_Cal_Gewicht;

/*********************************
 * Legato Image Asset
 * Name:   Symbol_Cal_Pulver
 * Size:   90x25 pixels
 * Type:   RGB Data
 * Format: RGB_565
 ***********************************/
extern leImage Symbol_Cal_Pulver;

/*********************************
 * Legato Image Asset
 * Name:   Symbol_Cal
 * Size:   56x25 pixels
 * Type:   RGB Data
 * Format: RGB_565
 ***********************************/
extern leImage Symbol_Cal;

/*********************************
 * Legato Image Asset
 * Name:   Symbol_OK
 * Size:   41x25 pixels
 * Type:   RGB Data
 * Format: RGB_565
 ***********************************/
extern leImage Symbol_OK;

/*********************************
 * Legato Image Asset
 * Name:   Symbol_Gram_sw
 * Size:   11x20 pixels
 * Type:   RGB Data
 * Format: RGB_565
 ***********************************/
extern leImage Symbol_Gram_sw;

/*********************************
 * Legato Image Asset
 * Name:   Symbol_Seite_Manual_right
 * Size:   36x8 pixels
 * Type:   RGB Data
 * Format: RGB_565
 ***********************************/
extern leImage Symbol_Seite_Manual_right;

/*********************************
 * Legato Image Asset
 * Name:   bitmap_white
 * Size:   320x240 pixels
 * Type:   RGB Data
 * Format: RGB_888
 ***********************************/
extern leImage bitmap_white;

/*****************************************************************************
 * Legato Graphics Font Assets
 *****************************************************************************/
/*********************************
 * Legato Font Asset
 * Name:         DIN2014Light32
 * Height:       19
 * Baseline:     26
 * Style:        Antialias
 * Glyph Count:  15
 * Range Count:  2
 * Glyph Ranges: 0x2C-0x39
                 0x73
***********************************/
extern leRasterFont DIN2014Light32;

/*********************************
 * Legato Font Asset
 * Name:         DIN2014Light28
 * Height:       19
 * Baseline:     23
 * Style:        Antialias
 * Glyph Count:  95
 * Range Count:  2
 * Glyph Ranges: 0x20-0x7E
***********************************/
extern leRasterFont DIN2014Light28;

/*********************************
 * Legato Font Asset
 * Name:         DIN2014Light36
 * Height:       19
 * Baseline:     29
 * Style:        Antialias
 * Glyph Count:  95
 * Range Count:  3
 * Glyph Ranges: 0x20-0x7E
***********************************/
extern leRasterFont DIN2014Light36;

/*********************************
 * Legato Font Asset
 * Name:         DIN2014Light24
 * Height:       19
 * Baseline:     20
 * Style:        Antialias
 * Glyph Count:  95
 * Range Count:  1
 * Glyph Ranges: 0x20-0x7E
***********************************/
extern leRasterFont DIN2014Light24;

/*********************************
 * Legato Font Asset
 * Name:         DIN2014Light62
 * Height:       19
 * Baseline:     52
 * Style:        Antialias
 * Glyph Count:  16
 * Range Count:  7
 * Glyph Ranges: 0x2D-0x39
                 0x41
                 0x43
                 0x4C
***********************************/
extern leRasterFont DIN2014Light62;

/*****************************************************************************
 * Legato String Table
 * Encoding        ASCII
 * Language Count: 1
 * String Count:   15
 *****************************************************************************/

// language IDs
#define language_Default    0

// string IDs
#define stringID_cupsel_weight_26_3    0
#define stringID_cupsel_weight_30_0    1
#define stringID_stats_value_time    2
#define stringID_unit_weight_g    3
#define stringID_cupsel_weight_26_4    4
#define stringID_manual_countdown_20    5
#define stringID_manual_countdown_18    6
#define stringID_manual_countdown_19    7
#define stringID_calib_weight_none    8
#define stringID_cupsel_weight_26_5    9
#define stringID_cupsel_weight_0_0    10
#define stringID_calib_CAL    11
#define stringID_stats_value_double    12
#define stringID_stats_value_single    13
#define stringID_unit_time_s    14

extern const leStringTable stringTable;


// string list
extern leTableString string_cupsel_weight_26_3;
extern leTableString string_cupsel_weight_30_0;
extern leTableString string_stats_value_time;
extern leTableString string_unit_weight_g;
extern leTableString string_cupsel_weight_26_4;
extern leTableString string_manual_countdown_20;
extern leTableString string_manual_countdown_18;
extern leTableString string_manual_countdown_19;
extern leTableString string_calib_weight_none;
extern leTableString string_cupsel_weight_26_5;
extern leTableString string_cupsel_weight_0_0;
extern leTableString string_calib_CAL;
extern leTableString string_stats_value_double;
extern leTableString string_stats_value_single;
extern leTableString string_unit_time_s;

void initializeStrings(void);
//DOM-IGNORE-BEGIN
#ifdef __cplusplus
}
#endif
//DOM-IGNORE-END

#endif /* LE_GEN_ASSETS_H */
