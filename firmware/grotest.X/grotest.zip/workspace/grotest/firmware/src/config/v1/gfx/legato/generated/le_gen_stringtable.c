#include "gfx/legato/generated/le_gen_assets.h"

/*****************************************************************************
 * Legato String Table
 * Encoding        ASCII
 * Language Count: 1
 * String Count:   15
 *****************************************************************************/

/*****************************************************************************
 * string table data
 * 
 * this table contains the raw character data for each string
 * 
 * unsigned short - number of indices in the table
 * unsigned short - number of languages in the table
 * 
 * index array (size = number of indices * number of languages
 * 
 * for each index in the array:
 *   unsigned byte - the font ID for the index
 *   unsigned byte[3] - the offset of the string codepoint data in
 *                      the table
 * 
 * string data is found by jumping to the index offset from the start
 * of the table
 * 
 * string data entry:
 *     unsigned short - length of the string in bytes (encoding dependent)
 *     codepoint data - the string data
 ****************************************************************************/

const uint8_t stringTable_data[152] =
{
    0x0F,0x00,0x01,0x00,0x04,0x40,0x00,0x00,0x04,0x46,0x00,0x00,0x02,0x4C,0x00,0x00,
    0x01,0x54,0x00,0x00,0x04,0x58,0x00,0x00,0x04,0x5E,0x00,0x00,0x04,0x62,0x00,0x00,
    0x04,0x66,0x00,0x00,0x04,0x6A,0x00,0x00,0x04,0x70,0x00,0x00,0x04,0x76,0x00,0x00,
    0x04,0x7C,0x00,0x00,0x02,0x82,0x00,0x00,0x02,0x8C,0x00,0x00,0x00,0x94,0x00,0x00,
    0x04,0x00,0x32,0x36,0x2E,0x33,0x04,0x00,0x33,0x30,0x2E,0x30,0x06,0x00,0x36,0x36,
    0x2E,0x32,0x33,0x30,0x01,0x00,0x67,0x00,0x04,0x00,0x32,0x36,0x2E,0x34,0x02,0x00,
    0x32,0x30,0x02,0x00,0x31,0x38,0x02,0x00,0x31,0x39,0x04,0x00,0x2D,0x2D,0x2E,0x2D,
    0x04,0x00,0x32,0x36,0x2E,0x35,0x03,0x00,0x30,0x2E,0x30,0x00,0x03,0x00,0x43,0x41,
    0x4C,0x00,0x07,0x00,0x31,0x32,0x35,0x2E,0x30,0x32,0x33,0x00,0x06,0x00,0x33,0x36,
    0x2E,0x31,0x30,0x34,0x01,0x00,0x73,0x00,
};

/* font asset pointer list */
leFont* fontList[5] =
{
    (leFont*)&DIN2014Light32,
    (leFont*)&DIN2014Light28,
    (leFont*)&DIN2014Light36,
    (leFont*)&DIN2014Light24,
    (leFont*)&DIN2014Light62,
};

const leStringTable stringTable =
{
    {
        LE_STREAM_LOCATION_ID_INTERNAL, // data location id
        (void*)stringTable_data, // data address pointer
        152, // data size
    },
    (void*)stringTable_data, // string table data
    fontList, // font lookup table
    LE_STRING_ENCODING_ASCII // encoding standard
};


// string list
leTableString string_cupsel_weight_26_3;
leTableString string_cupsel_weight_30_0;
leTableString string_stats_value_time;
leTableString string_unit_weight_g;
leTableString string_cupsel_weight_26_4;
leTableString string_manual_countdown_20;
leTableString string_manual_countdown_18;
leTableString string_manual_countdown_19;
leTableString string_calib_weight_none;
leTableString string_cupsel_weight_26_5;
leTableString string_cupsel_weight_0_0;
leTableString string_calib_CAL;
leTableString string_stats_value_double;
leTableString string_stats_value_single;
leTableString string_unit_time_s;

void initializeStrings(void)
{
    leTableString_Constructor(&string_cupsel_weight_26_3, stringID_cupsel_weight_26_3);
    leTableString_Constructor(&string_cupsel_weight_30_0, stringID_cupsel_weight_30_0);
    leTableString_Constructor(&string_stats_value_time, stringID_stats_value_time);
    leTableString_Constructor(&string_unit_weight_g, stringID_unit_weight_g);
    leTableString_Constructor(&string_cupsel_weight_26_4, stringID_cupsel_weight_26_4);
    leTableString_Constructor(&string_manual_countdown_20, stringID_manual_countdown_20);
    leTableString_Constructor(&string_manual_countdown_18, stringID_manual_countdown_18);
    leTableString_Constructor(&string_manual_countdown_19, stringID_manual_countdown_19);
    leTableString_Constructor(&string_calib_weight_none, stringID_calib_weight_none);
    leTableString_Constructor(&string_cupsel_weight_26_5, stringID_cupsel_weight_26_5);
    leTableString_Constructor(&string_cupsel_weight_0_0, stringID_cupsel_weight_0_0);
    leTableString_Constructor(&string_calib_CAL, stringID_calib_CAL);
    leTableString_Constructor(&string_stats_value_double, stringID_stats_value_double);
    leTableString_Constructor(&string_stats_value_single, stringID_stats_value_single);
    leTableString_Constructor(&string_unit_time_s, stringID_unit_time_s);
}
